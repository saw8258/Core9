export const firebaseConfig = {
  apiKey: "AIzaSyAaMGewA6XfcJ5_plWhbAKMU_GDKxxSY2g",
  authDomain: "core9-b77b5.firebaseapp.com",
  projectId: "core9-b77b5",
  storageBucket: "core9-b77b5.firebasestorage.app",
  messagingSenderId: "292979889874",
  appId: "1:292979889874:web:d97b016e847397f6397f0b"
};
